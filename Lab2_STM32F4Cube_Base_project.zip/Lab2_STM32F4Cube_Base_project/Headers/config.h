#ifndef HAL_CONFIG
#define HAL_CONFIG

#include "stm32f4xx_hal.h"
	
	void ADC_config(void);
	
#endif

